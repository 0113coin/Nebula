import random
import matplotlib.pyplot as plt

import pandas as pd
import numpy as np

#======================================================================================================================================
#추가해야 할 매개 변수
#언론
#공급 및  소비
#   자연재해    언론    
#
#======================================================================================================================================

event_bia = 0

stock_default = 5

선동계수 = 1
 
class news:
    def __init__(self,name,bia):#이름,명사,뉴스의 보도 편향 1:사실적 2:논리적 3:편파적
        self.name = name
        self.bia = bia
        
news("Times","Times",3) #세계적인 언론 보도사.모든 사건에 대해 매우 중립적인 태도로 보도
news("ABC","ABC",2) #ABC 계열 사의 언론 보도사.ABC 그룹 회사의 행보에 대해서 편파적으로 보도
news("CNN","CNN",3) #잡지 성향이 강한 언론 보도사,가십과 같은 자극적인 보도
 
 
class stock:
    def __init__(self,name,stock_price,stock_demand,stock_provide):
        self.name = name
        self.stock_price = stock_price
        self.stock_demand = stock_demand
        self.stock_provide = stock_provide
        
    def stock_price_change(self):
        print(f"{self.name} 주식의 주가를 변동합니다.")
        

        
        
        
        
        
        print(f"현재 주가 : {self.stock_price}")
    
    def check_stock_element(self):
        self.name = 1