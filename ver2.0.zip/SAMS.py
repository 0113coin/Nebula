import random
import matplotlib.pyplot as plt

import pandas as pd
import numpy as np

# 한글 폰트 사용을 위해서 세팅
from matplotlib import font_manager, rc
font_path = "C:/Windows/Fonts/NGULIM.TTF"
font = font_manager.FontProperties(fname=font_path).get_name()
rc('font', family=font)
   
# 가상의 주식 가격 데이터를 생성합니다.
dates = pd.date_range(start='2023-01-01', end='2023-01-31', freq='B') #B 는 business day 의 약자로 평일만 해당됨
prices = np.random.randint(100, 200, len(dates)) 
df = pd.DataFrame({'Date': dates, 'Price': prices})

# 일별 주식 가격 변동률을 계산합니다.
df['Daily_Return'] = df['Price'].pct_change()

# 변동성(표준 편차)을 계산합니다.
volatility = df['Daily_Return'].std()

# 시각화
plt.figure(figsize=(10, 6))
plt.plot(df['Date'], df['Price'], label='주식 가격', color='b')
plt.xlabel('날짜')
plt.ylabel('주식 가격')
plt.title('주식 가격 변동')
plt.legend()

plt.figure(figsize=(10, 6))
plt.plot(df['Date'], df['Daily_Return'], label='일별 변동률', color='r')
plt.xlabel('날짜')
plt.ylabel('일별 변동률')
plt.title('주식 가격 일별 변동률')
plt.legend()

plt.show()
