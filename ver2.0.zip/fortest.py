from openpyxl import load_workbook, Workbook
import time 
import urllib.request

대기시간 = 15
시작여부 = False
DB_path = "네뷸라\모의자산투자프로그램\ver2.0\DB.xlsx"
turn_count = 0

while 시작여부 == True: #게임 시작
    turn_count += 1 
    time.sleep(대기시간 * 60)
    
    
    
def load_User_DB():
    global wb,user_ws
    wb = load_workbook(DB_path)
    user_ws = wb["user_db"]

def saveFile():
    wb.save(DB_path)
    wb.close()



def shift_stockprice():
    print("주식값이 변동합니다.")
    load_User_DB
    
    bef_price = ""
           
    
    