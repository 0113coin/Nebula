def happen_negative_event():
    print("부정적 확률이 발생했습니다.")
    print("부정적 사건을 선별합니다.")
    print("")
    
happen_negative_event()