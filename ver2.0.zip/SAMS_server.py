from flask import Flask, request, render_template, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')

    # 엑셀 파일에서 데이터 읽기
    # 예를 들어, users.xlsx 파일에 사용자 데이터가 있는 경우
    # 해당 파일을 열고 데이터를 확인하여 일치 여부를 판단합니다.
    # 일치하면 다음 페이지로 이동하고, 일치하지 않으면 메시지를 출력합니다.

    # 예제에서는 사용자명이 "admin"이고 비밀번호가 "password"인 경우를 일치 조건으로 설정합니다.
    if str(username) == "admin" and str(password) == "password":
        return redirect(url_for('welcome', username=username))  
    else:
        return "인증 실패"
    
@app.route('/welcome')
def welcome():
    return render_template('main_page.html')
    
if __name__ == '__main__':
    app.run(port=5500)

